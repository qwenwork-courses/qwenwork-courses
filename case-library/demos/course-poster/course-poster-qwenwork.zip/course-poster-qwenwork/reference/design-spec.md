# 千问办公课程海报 · 设计规范

从两张真实海报逆向提取，对应两套主题：

| 主题 | 基准原图 | 气质 | 适用 |
| --- | --- | --- | --- |
| `classic` | `example_poster_fde.png`（1440×6780） | 冷绿灰底、克制、正式 | 认证课、企业内训、高单价 |
| `vivid` | `example_poster_five_disciplines.jpg`（原图 1640×11190） | 纯白底、亮绿、对比强 | 大众训练营、"人人可学" |

两张原图是唯一视觉基准，改模板后必须回看对比。

## 画布

| 项 | 值 |
| --- | --- |
| 设计宽度 | 1440px（CSS 1:1，Chrome `--force-device-scale-factor=1`） |
| 页面背景 | classic `#F7FBF9`（极浅冷绿灰）/ vivid `#FFFFFF` |
| 左右安全边距 | 74px，内容宽 1292px |
| 高度 | 由内容决定，典型 6000–8000px |

## 色彩

下表是 `classic` 的基准值。`vivid` 通过 `build_poster.py` 顶部 `THEMES` 字典做**整表字符串替换**实现，不是 CSS 变量——新引入的绿色色值必须同步登记进映射表，否则 vivid 主题漏色。

| 角色 | classic | vivid | 用途 |
| --- | --- | --- | --- |
| 主绿 Primary | `#17B862` | `#22C55E` | 章节标题、强调数字、绿字标签、badge 底、边框强调 |
| 深绿 Deep | `#0E9A50` | `#15803D` | 绿字上的次级层次（少用） |
| 页面底 | `#F7FBF9` | `#FFFFFF` | `.page` 背景 |
| 浅绿面板 | `#EDF8F3` | `#E8F8EE` | Day 课表左栏面板 |
| 浅绿渐变末 | `#F0FAF4` | `#F0FDF4` | 目标卡渐变、hero 右侧底块 |
| 序号圈底 | `#EAF7F0` | `#E8F8EE` | 收获行序号圆 |
| 条目圆点 | `#4FC98A` | `#22C55E` | 列表前的小绿点 |
| 正文墨色 | `#202422` | 同 | 标题、正文主色（不用纯黑 #000） |
| 次级文字 | `#3C4441` | 同 | 长段落正文 |
| 弱文字 | `#8A9691` | 同 | 英文副标、注释、时间值、署名 |
| 卡片白 | `#FFFFFF` | 同 | 所有主卡片 |
| 描边 | `#EAF3EE` | 同 | 卡片 1px 边框 |
| 虚线分隔 | `#DCEDE4` | 同 | 收获行之间、Day 卡内分隔 |

绿色只做点睛：一屏内绿色面积不超过 15%，主体是白卡 + 墨字。唯一例外是 `footer_cta` 尾屏——整块绿色渐变（`135deg, 深绿 → 主绿`）配白字，靠它收尾。

## 字体

统一用 macOS 系统字体苹方，不依赖第三方字体，换机不炸版：

```css
font-family:'PingFang SC','Hiragino Sans GB','Heiti SC',sans-serif;
```

字重只用三档，靠 `font-weight` 切换，不写 font-family 变体：

| class | weight | 落到的字面 | 用途 |
| --- | --- | --- | --- |
| （默认） | 400 | PingFang SC Regular | 正文、描述、时间值 |
| `.bd` | 600 | PingFang SC Semibold | 章节标题、小标题、标签、强调 |
| `.hv` | 700 | PingFang SC Bold（本机已装的 Bold 字面） | Hero 大标题、大数字、价格 |

苹方常规家族最重只到 Semibold(600)。`700` 会命中本机注册为 `PingFang SC / Bold` 的字体，比 Semibold 更重，这是大标题够冲的关键。换到没有该 Bold 字面的机器上，700 会静默回落成 Semibold、标题偏轻——此时整体再放大 4–6px 补偿，不要去换字体族。

苹方比普惠体 Heavy 视觉偏轻、字面偏宽，所以字号整体比原始海报上调一档，字距相应收紧（大标题 4px → 2px）。

字号（1440 画布）：

| 元素 | 字号 | 字重 | 字距 |
| --- | --- | --- | --- |
| Hero 主标题 / 副标题 | 94px | 700 | 2px |
| Hero 眉标"千问办公" | 27px | 600 | 1px |
| Hero 眉标英文 | 22px | 400 | 3px |
| Hero meta 行 | 28px | 600 | 0.5px |
| 章节标题 | 38px | 600 | 0.5px |
| 卡内 h3 | 42px | 600 | 0.5px |
| h3 英文副标 | 21px | 400 | 2.5px |
| 长段落正文 | 24px / lh 2.0 | 400 | — |
| 三格 strip | 23px | 600（标签） | — |
| 目标卡大数字 | 88px | 700 | 1px |
| 目标卡描述 | 22px / lh 1.8 | 400 | — |
| DAY 行标题 | 37px | 600 | 1.5px |
| DAY 主题（绿） | 34px | 600 | 0.5px |
| DAY badge 序号 | 25px（54×54 圆角块） | 600 | — |
| 课表小节标签 | 25px | 600 | — |
| 课表条目 | 24px / lh 1.7 | 400 | — |
| Day 卡 "DAY N" | 66px | 700 | 1px |
| Day 卡主题 | 26px | 600 | 0.5px |
| 时段行 | 22px | 600（标签） | — |
| 收获标题 | 31px | 600 | 0.3px |
| 收获描述 | 21px / lh 1.75 | 400 | — |
| 适合谁学条目 | 26px / lh 1.8 | 400 | — |
| 开班信息格 | 24px | 600（值） | — |
| 金句 | 34px / lh 1.9 | 600 | 0.3px |
| CTA 标题 | 48px | 700 | 1px |
| 价格数字 | 56px | 700 | 1px |

中文正文用 `text-align: justify` 会拉裂标点，一律左对齐。

## 模块骨架（自上而下）

共 16 个模块（下面的第 2 节"section 通用头"是公共骨架，不是模块），除 hero 外全部可缺省，渲染顺序就是 `sections` 数组顺序。按课程性质分两套常用组合：

- **认证/体系课**（classic）：intro → goals → schedule → gains → audience → logistics → quote → cta
- **大众/训练营**（vivid）：metrics → ladder → overview → scenarios → compare → valuegrid → audience → logistics → footer_cta

两组可以混搭，但有三对是"同一件事的两种讲法"，只能各选其一：`schedule` / `overview`（详细课表 vs 一天一行概览）、`cta` / `footer_cta`（白卡 vs 通栏绿尾屏）、`metrics` / `valuegrid`（三格大数字 vs 两列清单，同时上会重复）。

模块数控制在 8 个左右。17 个全塞进去图会长到一万多像素，读者滑到一半就走了。

### 1. hero（必需）

左栏自上而下，除标题外均可缺省：

1. 浅绿网格纸底纹（`repeating-linear-gradient` 22px 网格，`#D8EEE3`，仅覆盖眉标区域 ~230×110，opacity .55）；
2. **眉标**二选一——文字版（绿色"千问办公" + 灰色英文 program 行），或 `logo_lockup` 图片版（宽 268，给了图就不再画文字眉标）；
3. **badge** 胶囊：浅绿底 `#EDF8F3` + 1px 主绿边 + 绿 Bold 25px，radius 999，padding 10/24。放标题正上方，用来打"2 天线下工作坊 · 杭州"这类形态标；
4. **两行大标题**：首行墨色，次行主绿；含 `[[ ]]` 标记时改为按标记局部变色（同一行里墨绿混排）；
5. **subtitles**：1–2 行 28px 主绿 Semibold，行距 1.7。是标题的白话解释，不是 meta；
6. 665px 宽 1px 分隔线（仅当有 `meta` 时才画）+ **meta** 行；
7. **tags** 胶囊组：浅绿底无边框、绿 Bold 22px、radius 999、gap 12，≤ 4 个。承载"零代码 / 当场出交付物"这类卖点碎片。

右栏：`mark_3d.png` 宽 404px，绝对定位右上；底下垫 `#F0FAF4` 圆角块（radius 28）做呼吸感。

层级从上到下是"归属 → 形态 → 主张 → 解释 → 时间地点 → 卖点"，别打乱；元素给得越多就越要克制字号，7 个全上时标题外的字号一律不再上调。

### 2. section 通用头

绿色竖条（5×27px，radius 3）+ 12px 间距 + 绿色 Bold 标题。上边距 66px，下边距 28px。

### 3. intro（什么是 X?）

白卡 radius 20、padding 56、border 1px `#EAF3EE`、`box-shadow: 0 2px 18px rgba(23,184,98,.045)`。

内容：中文角色名 h3 → 英文全称（灰、字距 2.5px）→ 4–8 行长段落 → 底部三格 strip。

strip：外框 1px `#EAF3EE` radius 14，内部 3 等分用 1px 竖线分隔，每格 padding 26，**竖排两行**——上行图标（绿）+ 绿 Bold 21px 标签，下行墨色 Bold 24px 文本独占整格宽。和 `logistics` 同一套改法，原因相同（横排挤在一行会留孤字）。

### 4. goals（培养目标）

3 列等宽卡，gap 34。卡：`linear-gradient(160deg,#FFF 0%,#F0FAF4 100%)`、radius 18、padding 32、min-height 300。
左上大数字（`01/02/03` 主绿 Heavy 78px），右上 ↗ 箭头（浅绿 `#A8E3C4` 54px），下方描述，右下角 5 根递增小柱（浅绿，装饰）。

### 5. schedule（N 天课程安排）

外层白卡 padding 56。内部时间轴：
- 竖线 x=70（卡内坐标）宽 2px `#D8EDE2`，最后一天后终止；
- 节点圆 14px 白底 + 3px 主绿描边，压在竖线上；
- 天头：绿 badge（48×48 radius 12，白色 Bold 序号）+ `DAY N` 墨色 Bold + 细灰竖线 + 绿色主题；
- 天体两栏 gap 34：
  - 左：浅绿面板 `#EDF8F3` radius 16 padding 34，flex 1。内部按分组（理论讲解 / 实操演练 / 考核与结业）：绿 Bold 小标签 + 双列条目网格（`grid-template-columns: 1fr 1fr; column-gap 40; row-gap 22`），条目前 6px 绿点，条目垂直对齐 flex-start；
  - 右：固定宽 430 白卡，2px 主绿边框 radius 16 padding 32。顶部三个 8px 浅绿圆点 → `DAY N` 主绿 Heavy 58px → 主题墨色 Bold → 1px 虚线 → 时段行（左绿 Bold 标签 / 右灰时间，`justify-content: space-between`，行距 16）。右卡按左栏高度撑满（`align-items: stretch`），空白留白是刻意的。
- 天与天之间 1px 虚线 `#DCEDE4` + 上下留白 54。

### 6. gains（学员收获）

白卡。每行：序号圆（56px，`#EAF7F0` 底 + 1.5px 主绿边 + 主绿 Bold 数字）+ 右侧标题（支持 `认知重塑 ｜ FDE角色认知` 双段式）+ 描述。行间 1px 虚线，padding 26 0。

### 7. audience（适合谁学?）

白卡，2 列网格（column-gap 60 / row-gap 30），绿点 + 墨色 25px 文本，长条目自然换行且缩进对齐。

### 8. logistics（开班信息）

白卡 padding 0，3–4 等分格 1px 竖线分隔，每格 padding 32/28，**竖排两行**：

- 上行：线性图标（日历 / 定位 / 人群，绿，22px）+ 绿 Bold 21px 标签，gap 9；
- 下行：墨色 Bold 25px 值，独占整格宽度，`word-break: keep-all`。

原先是"图标 + 标签 + `｜` + 值"挤在一行，苹方字号上调后值频繁折行留孤字（"杭州西溪园 / 区"），改竖排把整格宽度让给值。格子设 `min-width:0` 防 flex 溢出。

### 9. quote（金句）

白卡 padding 56。左侧超大绿色 `"`（80px、opacity .35、绝对定位）。2–3 行 Bold 31px 墨字，右下 `—— 千问办公 ｜ 课程名` 灰色。右侧：直径 190 的 2px 主绿圆环内嵌 mark_3d（宽 120），圆环左下拉一条浅绿弧线装饰。

### 10. cta（报名咨询）

白卡 padding 46/56，三栏 flex：
- 左：QR 200×200（黑白）+ 绿色 Bold 21px 说明"扫描填写报名表单"；
- 中：`报名咨询` 主绿 Heavy 42px → 价格行（"课程定价" 墨色 Bold 26 + 数字主绿 Heavy 48 + "元/人" 墨色 Bold 26）→ 补充行（灰/墨 22px，含 `｜` 分隔的绿色 Bold 首期信息）；
- 右：`logo_cn.png` 宽 330。

页脚不留任何品牌小字——logo 已在 CTA 卡内。

### 11. metrics（数据看点）

等宽网格（`cols` 默认按条数取 1–3，gap 30）。每格白卡 radius 18 padding 36/32：右上 ↗ 浅绿箭头（44px）、大数字（主绿 Heavy 82px）+ 单位（主绿 Bold 30px，基线对齐）、下方 1–2 行说明（次级色 22px / lh 1.7）。

数字是这个模块唯一的主角，说明文字不要超过两行——超了就变成小段落，大数字的冲击力被稀释。

### 12. ladder（能力阶梯）

白卡 padding 56。每行两栏：

- 左：固定宽 118 的绿色标签块（`linear-gradient(150deg, 主绿, 深绿)`、radius 14、padding 16/0、居中），上排 `level`（白色 Bold 26px），下排 `name`（白色 Bold 27px）；
- 右：`title`（墨色 Bold 31px，支持行内标记）→ `desc`（次级色 22px / lh 1.75）→ `output` 行（浅绿底 `#EDF8F3` radius 10 padding 10/16 内联块，emoji + 绿 Bold 21px "产出：xxx"）。

行间 1px 虚线，行 padding 28 0。递进感靠 `level` 的编号本身表达，不额外画连线——五行以上再加竖线会显得拥挤。

### 13. overview（N 天一览）

白卡 padding 56。每天一块：

- 头行：`label` 绿色实心胶囊（主绿底、白色 Bold 24px、radius 999、padding 8/22）+ `tag` 浅绿描边胶囊（绿 Bold 22px）；
- `title` 墨色 Bold 34px（支持行内标记）；
- `desc` 次级色 23px / lh 1.75（支持行内标记）；
- `result` 行同 ladder 的 `output` 样式，文案前缀是"成果："。

块间 1px 虚线。这是 `schedule` 的轻量替代：不画时间轴、不分时段，一天压成一屏一眼能读完的四行。

### 14. scenarios（真实场景）

不用外层大卡，每条独立白卡（radius 18 padding 36/40，margin-bottom 22）：

- 标题行：emoji（32px）+ 墨色 Bold 32px 场景名；
- `flow` 行：墨色 24px 各段，段间插主绿 `→`（`.ar`，左右 margin 12），整行 `line-height:1.9` 允许折行；
- `involves` 行：绿 Bold 21px "涉及：xxx"。

流程箭头是这个模块的识别符，段数控制在 4 以内，否则一行放不下、折行后箭头落到行首很难看。

### 15. compare（对比）

整体 radius 18 overflow hidden、1px 描边。表头行：左格浅灰底 `#F6F8F7` + 弱文字 Bold 27px，右格浅绿底 `#EDF8F3` + 主绿 Bold 27px。数据行：左格 24px 弱化色（`#7A857F`），右格墨色 Bold 25px + 浅绿底。行间 1px 描边，格 padding 28/34，左右等宽。

右格永远是"我们"，靠底色和字重把视线拉过去；左格不许写具体友商名。

### 16. valuegrid（价值格）

等宽网格（`cols` 默认 2，gap 26）。每格白卡 radius 18 padding 36/34：`metric`（主绿 Heavy 62px，可以是 `01` 序号也可以是数字指标）→ `label`（墨色 Bold 29px）→ `desc`（次级色 22px / lh 1.75，支持行内标记）。

和 `metrics` 的区别：`metrics` 是三格横排的大数字看点，`valuegrid` 是两列多行的清单，用来罗列"你会带走什么"。

### 17. footer_cta（落地页尾屏）

整块通栏 section，`linear-gradient(135deg, 深绿 0%, 主绿 100%)`，padding 90/74，全部居中白字：

`headline`（白色 Heavy 62px）→ `sub`（白色 78% 透明 28px）→ `tags` 胶囊组（白色 18% 半透明底、白字 Bold 22px、radius 999）→ QR（248×248 白底 radius 16 padding 16）→ `qr_caption`（白色 72% 透明 22px）→ `brand_logo`（宽 250，用 `filter: brightness(0) invert(1)` 转纯白）。

必须是最后一个模块。绿色渐变块直接贴着页面底边收尾，裁切脚本会保留到最后一行非洋红像素，所以这块下面不要再留白卡。

### 行内标记

`build_poster.py` 的 `inline()` 把两种标记转成 span：

| 写法 | 渲染 | 用途 |
| --- | --- | --- |
| `**文字**` | 主绿 + Semibold | 句中最需要被记住的动作/结论 |
| `[[文字]]` | 主绿，字重跟随上下文 | 标题里的品类词、句中的关键名词 |

支持的字段：`hero.title_line1/2`、`ladder.title/desc`、`overview.title/desc`、`valuegrid.desc`。其余字段走纯文本转义。一屏内强调不超过两处。

## 排版铁律

1. 卡片一律 radius ≥ 16，白卡阴影极淡，禁止重投影。
2. 中文标点不许落行首：条目文案控制在单列宽度内自然折行，宁短勿长；超长条目提前手动断句。
3. 双列条目左右列条数不必相等，但左列先排满再溢出到右列会破坏阅读顺序——按"先左后右"逐行填充（CSS grid 默认行优先，正好）。
4. 章节之间靠留白分隔，不加横线。
5. 绿字用于"名词标签"，墨字承载信息主体；不要整段绿字。
