#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
千问办公课程海报生成器 —— JSON 内容 → HTML → PNG 长图

用法:
    python3 build_poster.py content.json -o /path/out_dir [--name poster] [--keep-html] [--slice]

设计基准: reference/design-spec.md + reference/example_poster_fde.png
"""

import argparse
import base64
import io
import json
import os
import re
import shutil
import subprocess
import sys
import time

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOGO_DIR = os.path.join(SKILL_DIR, "assets", "logos")

PAGE_W = 1440
PAGE_BG = (247, 251, 249)  # #F7FBF9

CHROME_CANDIDATES = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    shutil.which("google-chrome") or "",
    shutil.which("chromium") or "",
]


def find_chrome():
    for p in CHROME_CANDIDATES:
        if p and os.path.exists(p):
            return p
    raise SystemExit("找不到 Chrome/Chromium，请先安装 Google Chrome")


# ---------------------------------------------------------------- assets

def img_data_uri(path):
    """返回 (data_uri, width, height)"""
    from PIL import Image
    with open(path, "rb") as f:
        raw = f.read()
    w, h = Image.open(io.BytesIO(raw)).size
    ext = os.path.splitext(path)[1].lstrip(".").lower()
    mime = "jpeg" if ext in ("jpg", "jpeg") else ext
    return "data:image/%s;base64,%s" % (mime, base64.b64encode(raw).decode()), w, h


def logo(name):
    return img_data_uri(os.path.join(LOGO_DIR, name))


def make_qr_data_uri(url, px=560):
    import qrcode
    qr = qrcode.QRCode(version=None, box_size=10, border=2,
                       error_correction=qrcode.constants.ERROR_CORRECT_M)
    qr.add_data(url)
    qr.make(fit=True)
    im = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    im = im.resize((px, px))
    buf = io.BytesIO()
    im.save(buf, "PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode(), px, px


def esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


# 行内标记：**文字** → 绿色加粗强调，[[文字]] → 绿色
def inline(s):
    s = esc(s)
    s = re.sub(r"\*\*(.+?)\*\*", r'<b class="hl">\1</b>', s)
    s = re.sub(r"\[\[(.+?)\]\]", r'<span class="g">\1</span>', s)
    return s


# ---------------------------------------------------------------- themes
# 两套视觉：classic = 首期 FDE 海报（稳重、冷绿灰底）；vivid = 五项修炼海报（明亮、纯白底、胶囊多）
# 靠替换 CSS 里的色值字面量实现，避免把整份样式改成 CSS 变量。
THEMES = {
    "classic": {},
    "vivid": {
        "#17B862": "#22C55E",   # 主绿
        "#0E9A50": "#15803D",   # 深绿
        "#F7FBF9": "#FFFFFF",   # 页面底
        "#EDF8F3": "#E8F8EE",   # 浅绿面板
        "#F0FAF4": "#F0FDF4",   # 渐变末端
        "#EAF7F0": "#E8F8EE",   # 序号圈底
        "#4FC98A": "#22C55E",   # 条目圆点
    },
}


def themed_css(css, theme):
    for old, new in THEMES.get(theme, {}).items():
        css = css.replace(old, new)
    return css


# ---------------------------------------------------------------- icons

ICONS = {
    "question": '<circle cx="12" cy="12" r="9"/><path d="M9.4 9.2a2.7 2.7 0 1 1 3.4 2.6c-.6.2-.9.7-.9 1.3v.5"/><circle cx="12" cy="17" r=".9" fill="currentColor" stroke="none"/>',
    "target": '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.6"/><circle cx="12" cy="12" r="1.1" fill="currentColor" stroke="none"/>',
    "trend": '<path d="M4 17.5 10 11l3.4 3.4L20 7.4"/><path d="M15 7h5v5"/>',
    "calendar": '<rect x="3.5" y="5.2" width="17" height="15" rx="2.6"/><path d="M3.5 10h17M8.5 3.4v3.6M15.5 3.4v3.6"/>',
    "pin": '<path d="M12 21c4.2-4.6 6.4-7.7 6.4-10.4A6.4 6.4 0 0 0 5.6 10.6C5.6 13.3 7.8 16.4 12 21z"/><circle cx="12" cy="10.4" r="2.4"/>',
    "people": '<circle cx="9" cy="8.4" r="3.2"/><path d="M2.8 19.6c0-3.4 2.8-5.6 6.2-5.6s6.2 2.2 6.2 5.6"/><path d="M16.4 5.6a3.1 3.1 0 0 1 0 6M18 13.9c2.2.5 3.6 2.2 3.6 4.5"/>',
    "spark": '<path d="M12 3.2l1.9 5.3 5.3 1.9-5.3 1.9L12 17.6l-1.9-5.3L4.8 10.4l5.3-1.9z"/>',
    "book": '<path d="M4.2 5.2c2.9-1.2 5.3-1.2 7.8.5 2.5-1.7 4.9-1.7 7.8-.5v13c-2.9-1.2-5.3-1.2-7.8.5-2.5-1.7-4.9-1.7-7.8-.5z"/><path d="M12 5.7v13"/>',
    "clock": '<circle cx="12" cy="12" r="8.8"/><path d="M12 7v5.3l3.4 2.1"/>',
    "price": '<path d="M20.4 12.6 12.6 20.4a2 2 0 0 1-2.8 0L3.6 14.2a2 2 0 0 1 0-2.8L11.4 3.6a2 2 0 0 1 1.4-.6h5.6a2 2 0 0 1 2 2v6.2a2 2 0 0 1-.6 1.4z"/><circle cx="16.2" cy="7.8" r="1.3" fill="currentColor" stroke="none"/>',
    "rocket": '<path d="M13.6 4.6c3.2-1.6 6.4-1.4 6.4-1.4s.2 3.2-1.4 6.4c-1.3 2.6-4.2 5.4-6.6 7.2l-3.6-3.6c1.8-2.4 4.6-5.3 7.2-6.6z"/><path d="M8.4 13.2 5.2 10M6.6 16.2c-1.2 1.2-2.8 4-2.8 4s2.8-1.6 4-2.8"/>',
}


def icon_svg(name, size=23, cls="ic"):
    body = ICONS.get(name, ICONS["spark"])
    return ('<svg class="%s" viewBox="0 0 24 24" width="%d" height="%d" fill="none" '
            'stroke="currentColor" stroke-width="1.7" stroke-linecap="round" '
            'stroke-linejoin="round">%s</svg>' % (cls, size, size, body))


# ---------------------------------------------------------------- CSS

CSS = """
*{margin:0;padding:0;box-sizing:border-box}
/* 画布哨兵色：页面之外一律洋红，供裁剪脚本精确定位内容底边 */
html{background:#FF00FF}
body{
  width:1440px;background:#FF00FF;
  font-family:'PingFang SC','Hiragino Sans GB','Heiti SC',sans-serif;
  font-weight:400;
  color:#202422;-webkit-font-smoothing:antialiased;
}
.page{width:1440px;padding:74px 74px 78px;background:#F7FBF9}
/* 苹方最重的常规字重是 Semibold(600)；700 会落到本机注册为 PingFang SC/Bold 的字体，用于大标题 */
.hv{font-weight:700}
.bd{font-weight:600}
.g{color:#17B862}

/* ---------- hero ---------- */
.hero{position:relative;min-height:452px;margin-bottom:14px}
.hero-grid{
  position:absolute;left:-4px;top:-30px;width:238px;height:118px;opacity:.55;
  background-image:repeating-linear-gradient(to right,#D8EEE3 0 1px,transparent 1px 22px),
                   repeating-linear-gradient(to bottom,#D8EEE3 0 1px,transparent 1px 22px);
}
.hero-eyebrow{position:relative;display:flex;align-items:baseline;gap:16px;padding-top:12px}
.hero-eyebrow .nm{font-size:27px;letter-spacing:1px;color:#17B862}
.hero-eyebrow .pg{font-size:22px;letter-spacing:3px;color:#9AA6A1}
.hero-title{margin-top:24px}
/* 苹方没有比 Bold 更重的字面，用同色描边把大标题字形加粗 */
.hero-title div{font-size:94px;line-height:1.2;letter-spacing:2px;
  -webkit-text-stroke:1.6px currentColor;paint-order:stroke fill}
.hero-rule{width:665px;height:1px;background:#E3EDE8;margin:34px 0 26px}
.hero-meta{font-size:28px;letter-spacing:.5px;color:#202422}
.hero-art{position:absolute;right:-6px;top:-34px;width:452px;height:452px;
  display:flex;align-items:center;justify-content:center;
  background:linear-gradient(150deg,#F4FBF7 0%,#EAF7F0 100%);border-radius:30px}
.hero-art img{width:404px;height:auto;display:block}

/* ---------- section ---------- */
.sec-head{display:flex;align-items:center;gap:14px;margin:68px 0 30px}
.sec-bar{width:6px;height:34px;border-radius:3px;background:#17B862;flex:none}
.sec-title{font-size:38px;letter-spacing:.5px;color:#17B862}
.card{background:#fff;border:1px solid #EAF3EE;border-radius:20px;
  box-shadow:0 2px 18px rgba(23,184,98,.045)}
.pad{padding:56px}

/* ---------- intro ---------- */
.intro-h3{font-size:42px;letter-spacing:.5px}
.intro-en{margin-top:9px;font-size:21px;letter-spacing:2.5px;color:#9AA6A1}
.intro-body{margin-top:30px;font-size:24px;line-height:2.0;color:#3C4441;text-align:left}
.strip{display:flex;margin-top:40px;border:1px solid #EAF3EE;border-radius:14px;overflow:hidden}
.strip-cell{flex:1;min-width:0;display:flex;flex-direction:column;gap:9px;
  padding:26px 26px;border-left:1px solid #EAF3EE;font-size:23px;line-height:1.5}
.strip-cell:first-child{border-left:none}
.strip-cell .st-top{display:flex;align-items:center;gap:9px;font-size:21px;color:#17B862}
.strip-cell .ic{color:#17B862;flex:none}
.strip-cell .tx{color:#202422;font-size:24px;line-height:1.35;word-break:keep-all}
.bar{color:#C9D8D2;margin:0 6px}

/* ---------- goals ---------- */
.goals{display:grid;grid-template-columns:repeat(3,1fr);gap:34px}
.goal{position:relative;min-height:312px;padding:32px 34px 34px;border-radius:18px;
  border:1px solid #EAF3EE;background:linear-gradient(160deg,#FFFFFF 0%,#F0FAF4 100%);
  box-shadow:0 2px 18px rgba(23,184,98,.04)}
.goal .num{font-size:88px;line-height:1;color:#17B862;letter-spacing:1px}
.goal .arw{position:absolute;right:34px;top:34px;font-size:54px;line-height:1;color:#A8E3C4}
.goal .dsc{margin-top:26px;font-size:22px;line-height:1.8;color:#3C4441}
.goal .bars{position:absolute;right:32px;bottom:30px;display:flex;align-items:flex-end;gap:5px}
.goal .bars i{display:block;width:8px;border-radius:2px;background:#B6E7CD}

/* ---------- schedule ---------- */
.days{position:relative}
.days::before{content:'';position:absolute;left:15px;top:22px;bottom:26px;width:2px;background:#D8EDE2}
.day{position:relative;padding-left:66px}
.day+.day{margin-top:54px;padding-top:54px;border-top:1px dashed #DCEDE4}
.day-node{position:absolute;left:8px;top:20px;width:16px;height:16px;border-radius:50%;
  background:#fff;border:3px solid #17B862;box-sizing:border-box}
.day+.day .day-node{top:74px}
.day-head{display:flex;align-items:center;gap:18px}
.day-badge{width:54px;height:54px;border-radius:13px;background:#17B862;color:#fff;
  font-size:25px;display:flex;align-items:center;justify-content:center;flex:none}
.day-name{font-size:37px;letter-spacing:1.5px}
.day-sep{width:1px;height:34px;background:#D5E3DD;flex:none}
.day-theme{font-size:34px;color:#17B862;letter-spacing:.5px}
.day-body{display:flex;align-items:stretch;gap:34px;margin-top:28px}
.day-panel{flex:1;background:#EDF8F3;border-radius:16px;padding:34px 36px 38px}
.grp+.grp{margin-top:30px}
.grp-label{font-size:25px;color:#17B862;margin-bottom:16px}
.grp-items{display:grid;grid-template-columns:1fr 1fr;column-gap:40px;row-gap:22px}
.it{display:flex;align-items:flex-start;gap:12px;font-size:24px;line-height:1.7;color:#202422}
.it .dot{width:7px;height:7px;border-radius:50%;background:#4FC98A;flex:none;margin-top:14px}
.day-card{width:430px;flex:none;background:#fff;border:2px solid #17B862;border-radius:16px;
  padding:30px 34px 34px}
.day-card .dots{display:flex;gap:7px;margin-bottom:22px}
.day-card .dots i{width:9px;height:9px;border-radius:50%;background:#C6EAD8;display:block}
.day-card .dn{font-size:66px;line-height:1.1;color:#17B862;letter-spacing:1px}
.day-card .dt{margin-top:10px;font-size:26px;letter-spacing:.5px}
.day-card hr{border:none;border-top:1px dashed #D6E9DF;margin:24px 0 22px}
.slot{display:flex;justify-content:space-between;align-items:baseline;font-size:22px}
.slot+.slot{margin-top:16px}
.slot .sl{color:#17B862}
.slot .sv{color:#8A9691;letter-spacing:.5px}

/* ---------- gains ---------- */
.gain{display:flex;align-items:flex-start;gap:26px;padding:26px 0}
.gain+.gain{border-top:1px dashed #DCEDE4}
.gain .no{width:58px;height:58px;flex:none;border-radius:50%;background:#EAF7F0;
  border:1.5px solid #9FDCBE;color:#17B862;font-size:26px;
  display:flex;align-items:center;justify-content:center}
.gain .gt{font-size:31px;letter-spacing:.3px}
.gain .gd{margin-top:11px;font-size:21px;line-height:1.75;color:#6E7B76}

/* ---------- audience ---------- */
.aud{display:grid;grid-template-columns:1fr 1fr;column-gap:60px;row-gap:30px}
.aud .it{font-size:26px;line-height:1.8}
.aud .it .dot{margin-top:16px}

/* ---------- logistics ---------- */
.logi{display:flex}
.logi-cell{flex:1;min-width:0;display:flex;flex-direction:column;gap:10px;
  padding:32px 28px;border-left:1px solid #EAF3EE;font-size:24px;line-height:1.5}
.logi-cell:first-child{border-left:none}
.logi-cell .lg-top{display:flex;align-items:center;gap:9px;font-size:21px;color:#17B862}
.logi-cell .lg-val{font-size:25px;line-height:1.35;color:#0F1C17;
  letter-spacing:-.2px;word-break:keep-all}
.logi-cell .ic{color:#17B862;flex:none}

/* ---------- quote ---------- */
.quote{position:relative;display:flex;align-items:center;gap:40px}
.quote .mk{position:absolute;left:-6px;top:52px;font-size:82px;line-height:1;
  color:#17B862;opacity:.32;font-family:Georgia,serif}
.quote .qbody{flex:1;padding-left:78px}
.quote .ql{font-size:34px;line-height:1.9;letter-spacing:.3px}
.quote .qa{margin-top:26px;text-align:right;font-size:22px;color:#9AA6A1;letter-spacing:1px}
.quote .qart{position:relative;width:230px;flex:none;display:flex;justify-content:center}
.quote .ring{width:190px;height:190px;border-radius:50%;border:2px solid #17B862;
  display:flex;align-items:center;justify-content:center;background:#fff}
.quote .ring img{width:118px;height:auto;display:block}
.quote .swoosh{position:absolute;left:-18px;bottom:-58px;width:176px;height:64px;
  border-bottom:2px solid #BEE8D3;border-radius:0 0 60% 40%;transform:rotate(-4deg);
  z-index:0;pointer-events:none}

/* ---------- cta ---------- */
.cta{display:flex;align-items:center;gap:52px;padding:46px 56px}
.cta .qr{width:212px;flex:none;text-align:center}
.cta .qr img{width:200px;height:200px;display:block;margin:0 auto}
.cta .qr .cap{margin-top:14px;font-size:21px;color:#17B862;letter-spacing:.5px}
.cta .mid{flex:1}
.cta .ct{font-size:48px;color:#17B862;letter-spacing:1px}
.cta .pr{margin-top:20px;font-size:27px;letter-spacing:.5px}
.cta .pr .amt{font-size:56px;color:#17B862;margin:0 5px;letter-spacing:1px}
.cta .nt{margin-top:14px;font-size:22px;line-height:1.7;color:#3C4441}
.cta .nt .gn{color:#17B862}
.cta .brand{flex:none}
.cta .brand img{display:block}
"""

# 第二套参考海报（五项修炼）新增的模块样式
CSS2 = """
/* ---------- 行内强调 ---------- */
.hl{color:#17B862;font-weight:600}

/* ---------- hero 扩展 ---------- */
.hero-lockup{margin-bottom:30px}
.hero-lockup img{display:block}
.hero-badge{display:inline-block;padding:13px 30px;border-radius:40px;
  background:#F5F5F5;color:#666666;font-size:25px;letter-spacing:1px}
.hero-subs{margin-top:22px}
.hero-subs div{font-size:32px;line-height:1.55;color:#17B862;letter-spacing:.5px}
.chips{display:flex;flex-wrap:wrap;gap:18px;margin-top:30px}
.chip{padding:12px 28px;border-radius:40px;background:#E8F8EE;color:#17B862;
  font-size:24px;letter-spacing:.5px;white-space:nowrap}

/* ---------- metrics 数据亮点 ---------- */
.metrics{display:grid;gap:32px}
.metric{position:relative;overflow:hidden;padding:44px 34px 40px;border-radius:18px;
  border:1px solid #EAF3EE;background:#fff;text-align:center;
  box-shadow:0 2px 18px rgba(23,184,98,.04)}
.metric .arw{position:absolute;right:26px;top:34px;font-size:76px;line-height:1;
  color:#EDF3EF;z-index:0}
.metric .val{position:relative;z-index:1;display:flex;align-items:baseline;
  justify-content:center;gap:2px;color:#17B862}
.metric .val .n{font-size:82px;line-height:1;letter-spacing:1px}
.metric .val .u{font-size:31px;letter-spacing:.5px}
.metric .ln{position:relative;z-index:1;margin-top:18px;font-size:24px;
  line-height:1.65;color:#3C4441}

/* ---------- ladder 分级进阶 ---------- */
.lad+.lad{margin-top:30px;padding-top:30px;border-top:1px dashed #DCEDE4}
.lad{display:flex;align-items:flex-start;gap:28px}
.lad-tag{width:118px;flex:none;padding:16px 8px;border-radius:16px;background:#17B862;
  color:#fff;text-align:center;line-height:1.25}
.lad-tag .lv{display:block;font-size:22px;opacity:.9}
.lad-tag .nm{display:block;font-size:27px;margin-top:2px}
.lad-bd{flex:1}
.lad-bd .t{font-size:32px;letter-spacing:.3px}
.lad-bd .d{margin-top:13px;font-size:23px;line-height:1.7;color:#6E7B76}
.out{margin-top:15px;font-size:23px;color:#17B862;letter-spacing:.3px}
.out .em{margin-right:9px}

/* ---------- overview 课程全景 ---------- */
.ov+.ov{margin-top:30px;padding-top:30px;border-top:1px dashed #DCEDE4}
.ov-head{display:flex;align-items:center;gap:16px}
.ov-pill{padding:9px 24px;border-radius:40px;background:#17B862;color:#fff;
  font-size:24px;letter-spacing:.5px;flex:none}
.ov-tag{font-size:25px;color:#17B862}
.ov .t{margin-top:17px;font-size:30px;line-height:1.5;letter-spacing:.3px}
.ov .d{margin-top:12px;font-size:23px;line-height:1.7;color:#6E7B76}

/* ---------- scenarios 实战场景 ---------- */
.scn+.scn{margin-top:30px}
.scn{padding:40px 44px;border-radius:18px;border:1px solid #EAF3EE;background:#fff;
  box-shadow:0 2px 18px rgba(23,184,98,.04)}
.scn .t{display:flex;align-items:center;gap:14px;font-size:31px;letter-spacing:.3px}
.scn .t .em{font-size:33px}
.scn .fl{margin-top:22px;font-size:23px;line-height:1.85;color:#3C4441}
.scn .fl .ar{color:#9AA6A1;margin:0 9px}
.scn .inv{margin-top:20px;font-size:23px;line-height:1.6;color:#17B862}

/* ---------- compare 对比表 ---------- */
.cmp{border:1px solid #EAF3EE;border-radius:18px;overflow:hidden;background:#fff}
.cmp-row{display:flex}
.cmp-row+.cmp-row{border-top:1px solid #EAF3EE}
.cmp-cell{flex:1;padding:30px 36px;font-size:24px;line-height:1.65}
.cmp-cell+.cmp-cell{border-left:1px solid #EAF3EE}
.cmp-head .cmp-cell{padding:28px 36px;text-align:center;font-size:26px}
.cmp-head .l{background:#F5F6F5;color:#8A9691}
.cmp-head .r{background:#E8F8EE;color:#17B862}
.cmp-row .l{color:#8A9691}
.cmp-row .r{color:#202422}

/* ---------- valuegrid 价值网格 ---------- */
.vg{display:grid;gap:30px}
.vg-cell{padding:36px 38px 34px;border-radius:18px;border:1px solid #EAF3EE;background:#fff;
  box-shadow:0 2px 18px rgba(23,184,98,.04)}
.vg-cell .m{font-size:46px;line-height:1;color:#17B862;letter-spacing:1px}
.vg-cell .l{margin-top:18px;font-size:27px;letter-spacing:.3px}
.vg-cell .d{margin-top:12px;font-size:22px;line-height:1.7;color:#6E7B76}

/* ---------- footer_cta 深绿通栏 ---------- */
.fcta{margin:70px -74px -78px;padding:82px 74px 78px;text-align:center;
  background:linear-gradient(135deg,#15803D 0%,#17B862 62%,#3FD07F 100%);color:#fff}
.fcta .h{font-size:52px;letter-spacing:1px;-webkit-text-stroke:.8px currentColor}
.fcta .s{margin-top:24px;font-size:28px;line-height:1.6;color:rgba(255,255,255,.92)}
.fcta .chips{justify-content:center;gap:22px;margin-top:38px}
.fcta .chip{background:rgba(255,255,255,.18);color:#fff;font-size:25px;padding:14px 30px}
.fcta .qrwrap{margin-top:46px}
.fcta .qrwrap img{display:block;margin:0 auto;border-radius:14px;background:#fff;padding:12px}
.fcta .qrcap{margin-top:20px;font-size:25px;color:rgba(255,255,255,.95)}
.fcta .fbrand{margin-top:30px}
/* logo 原图是绿符号+黑字，压成纯白置于深绿底 */
.fcta .fbrand img{display:block;margin:0 auto;filter:brightness(0) invert(1)}
"""


# ---------------------------------------------------------------- renderers

def r_hero(hero, brand):
    uri, w, h = logo(hero.get("art", "mark_3d.png"))
    art_w = 404
    art_h = int(round(h * art_w / w))

    # 顶部 logo 锁定组合（给的话就替代文字眉标）
    lockup = ""
    if hero.get("logo_lockup"):
        lu, lw, lh = logo(hero["logo_lockup"])
        bw = 268
        bh = int(round(lh * bw / lw))
        lockup = ('<div class="hero-lockup"><img src="%s" width="%d" height="%d" alt=""></div>'
                  % (lu, bw, bh))
        eyebrow = ""
    else:
        eyebrow = ('<div class="hero-eyebrow"><span class="nm bd">%s</span>'
                   '<span class="pg">%s</span></div>'
                   % (esc(brand.get("name_cn", "千问办公")),
                      esc(brand.get("program_en", "QwenWork Certified Program"))))

    badge = ('<div class="hero-badge bd">%s</div>' % esc(hero["badge"])) if hero.get("badge") else ""

    # 标题：含 [[ ]] 的行按行内变色渲染；不含标记时沿用"第二行整行绿"
    lines = []
    for i, key in enumerate(("title_line1", "title_line2")):
        raw = hero.get(key)
        if not raw:
            continue
        if "[[" in raw:
            lines.append('<div class="hv">%s</div>' % inline(raw))
        else:
            lines.append('<div class="hv%s">%s</div>' % (" g" if i == 1 else "", esc(raw)))
    title = '<div class="hero-title">%s</div>' % "".join(lines)

    subs = ""
    if hero.get("subtitles"):
        subs = ('<div class="hero-subs">%s</div>'
                % "".join('<div class="bd">%s</div>' % esc(x) for x in hero["subtitles"]))

    chips = ""
    if hero.get("tags"):
        chips = ('<div class="chips">%s</div>'
                 % "".join('<span class="chip bd">%s</span>' % esc(t) for t in hero["tags"]))

    rule = '<div class="hero-rule"></div>' if hero.get("meta") else ""
    meta = ('<div class="hero-meta bd">%s</div>' % esc(hero["meta"])) if hero.get("meta") else ""

    return """
<section class="hero">
  <div class="hero-grid"></div>
  %s%s%s%s%s%s%s
  <div class="hero-art"><img src="%s" width="%d" height="%d" alt=""></div>
</section>""" % (lockup, eyebrow, badge, title, subs, rule + meta, chips,
                 uri, art_w, art_h)


def sec_head(title):
    if not title:
        return ""
    return ('<div class="sec-head"><span class="sec-bar"></span>'
            '<span class="sec-title bd">%s</span></div>' % esc(title))


def r_intro(s):
    strip = ""
    cells = s.get("strip") or []
    if cells:
        parts = []
        for c in cells:
            parts.append(
                '<div class="strip-cell">'
                '<div class="st-top">%s<span class="bd">%s</span></div>'
                '<div class="tx bd">%s</div></div>'
                % (icon_svg(c.get("icon", "spark")), esc(c.get("label", "")),
                   esc(c.get("text", ""))))
        strip = '<div class="strip">%s</div>' % "".join(parts)

    paras = s.get("body") or []
    if isinstance(paras, str):
        paras = [paras]
    body = "".join('<p class="intro-body">%s</p>' % esc(p) for p in paras)

    en = ('<div class="intro-en">%s</div>' % esc(s["role_en"])) if s.get("role_en") else ""
    h3 = ('<div class="intro-h3 bd">%s</div>' % esc(s["role_cn"])) if s.get("role_cn") else ""
    return sec_head(s.get("title")) + '<div class="card pad">%s%s%s%s</div>' % (h3, en, body, strip)


def r_goals(s):
    cells = []
    for i, g in enumerate(s.get("items", []), 1):
        if isinstance(g, dict):
            txt = g.get("text", "")
        else:
            txt = g
        bars = "".join('<i style="height:%dpx"></i>' % hh for hh in (9, 14, 19, 25, 31))
        cells.append(
            '<div class="goal"><div class="num hv">%02d</div><div class="arw">↗</div>'
            '<div class="dsc">%s</div><div class="bars">%s</div></div>' % (i, esc(txt), bars))
    return sec_head(s.get("title")) + '<div class="goals">%s</div>' % "".join(cells)


def r_schedule(s):
    days_html = []
    for i, d in enumerate(s.get("days", []), 1):
        groups = []
        for g in d.get("groups", []):
            items = "".join(
                '<div class="it"><span class="dot"></span><span>%s</span></div>' % esc(x)
                for x in g.get("items", []))
            groups.append('<div class="grp"><div class="grp-label bd">%s</div>'
                          '<div class="grp-items">%s</div></div>'
                          % (esc(g.get("label", "")), items))
        slots = "".join(
            '<div class="slot"><span class="sl bd">%s</span><span class="sv">%s</span></div>'
            % (esc(sl.get("label", "")), esc(sl.get("value", "")))
            for sl in d.get("slots", []))
        label = d.get("label") or ("DAY %d" % i)
        days_html.append("""
  <div class="day">
    <div class="day-node"></div>
    <div class="day-head">
      <span class="day-badge bd">%02d</span>
      <span class="day-name bd">%s</span>
      <span class="day-sep"></span>
      <span class="day-theme bd">%s</span>
    </div>
    <div class="day-body">
      <div class="day-panel">%s</div>
      <aside class="day-card">
        <div class="dots"><i></i><i></i><i></i></div>
        <div class="dn hv">%s</div>
        <div class="dt bd">%s</div>
        <hr>
        %s
      </aside>
    </div>
  </div>""" % (i, esc(label), esc(d.get("theme", "")), "".join(groups),
              esc(label), esc(d.get("theme", "")), slots))
    return (sec_head(s.get("title"))
            + '<div class="card pad"><div class="days">%s</div></div>' % "".join(days_html))


def r_gains(s):
    rows = []
    for i, g in enumerate(s.get("items", []), 1):
        title = g.get("title", "") if isinstance(g, dict) else str(g)
        desc = g.get("desc", "") if isinstance(g, dict) else ""
        if "｜" in title:
            a, b = title.split("｜", 1)
            title_html = '%s<span class="bar">｜</span>%s' % (esc(a.strip()), esc(b.strip()))
        else:
            title_html = esc(title)
        d = ('<div class="gd">%s</div>' % esc(desc)) if desc else ""
        rows.append('<div class="gain"><div class="no bd">%d</div><div>'
                    '<div class="gt bd">%s</div>%s</div></div>' % (i, title_html, d))
    return sec_head(s.get("title")) + '<div class="card pad">%s</div>' % "".join(rows)


def r_audience(s):
    items = "".join('<div class="it"><span class="dot"></span><span>%s</span></div>' % esc(x)
                    for x in s.get("items", []))
    return sec_head(s.get("title")) + '<div class="card pad"><div class="aud">%s</div></div>' % items


def r_logistics(s):
    cells = []
    for c in s.get("items", []):
        cells.append('<div class="logi-cell">'
                     '<div class="lg-top">%s<span class="bd">%s</span></div>'
                     '<div class="lg-val bd">%s</div></div>'
                     % (icon_svg(c.get("icon", "spark")), esc(c.get("label", "")),
                        esc(c.get("value", ""))))
    return sec_head(s.get("title")) + '<div class="card"><div class="logi">%s</div></div>' % "".join(cells)


def r_quote(s):
    uri, w, h = logo("mark_3d.png")
    iw = 118
    ih = int(round(h * iw / w))
    lines = "".join('<div class="ql bd">%s</div>' % esc(l) for l in s.get("lines", []))
    attr = ('<div class="qa">—— %s</div>' % esc(s["attribution"])) if s.get("attribution") else ""
    return (sec_head(s.get("title"))
            + """<div class="card pad quote">
  <div class="mk">&ldquo;</div>
  <div class="qbody">%s%s</div>
  <div class="qart"><div class="ring"><img src="%s" width="%d" height="%d" alt=""></div>
    <div class="swoosh"></div></div>
</div>""" % (lines, attr, uri, iw, ih))


def r_cta(s):
    qr_html = ""
    qr = None
    if s.get("qr_image") and os.path.exists(s["qr_image"]):
        qr = img_data_uri(s["qr_image"])
    elif s.get("qr_url"):
        try:
            qr = make_qr_data_uri(s["qr_url"])
        except Exception as e:
            sys.stderr.write("QR 生成失败(%s)，跳过二维码\n" % e)
    if qr:
        cap = s.get("qr_caption", "扫描填写报名表单")
        qr_html = ('<div class="qr"><img src="%s" alt=""><div class="cap bd">%s</div></div>'
                   % (qr[0], esc(cap)))

    price = ""
    if s.get("price"):
        price = ('<div class="pr bd">%s<span class="amt hv">%s</span>%s</div>'
                 % (esc(s.get("price_prefix", "课程定价")), esc(s["price"]),
                    esc(s.get("price_suffix", "元/人"))))

    note = ""
    if s.get("note") or s.get("note_green"):
        seg = []
        if s.get("note"):
            seg.append('<span class="bd">%s</span>' % esc(s["note"]))
        if s.get("note_green"):
            seg.append('<span class="gn bd">%s</span>' % esc(s["note_green"]))
        note = '<div class="nt">%s</div>' % '<span class="bar">｜</span>'.join(seg)

    luri, lw, lh = logo(s.get("brand_logo", "logo_cn.png"))
    bw = 330
    bh = int(round(lh * bw / lw))
    return (sec_head(s.get("title"))
            + """<div class="card cta">
  %s
  <div class="mid"><div class="ct hv">%s</div>%s%s</div>
  <div class="brand"><img src="%s" width="%d" height="%d" alt=""></div>
</div>""" % (qr_html, esc(s.get("headline", "报名咨询")), price, note, luri, bw, bh))


def r_metrics(s):
    items = s.get("items", [])
    cells = []
    for m in items:
        lines = m.get("lines") or ([m["desc"]] if m.get("desc") else [])
        body = "".join('<div>%s</div>' % esc(l) for l in lines)
        unit = ('<span class="u bd">%s</span>' % esc(m["unit"])) if m.get("unit") else ""
        cells.append('<div class="metric"><div class="arw">↗</div>'
                     '<div class="val"><span class="n hv">%s</span>%s</div>'
                     '<div class="ln">%s</div></div>'
                     % (esc(m.get("value", "")), unit, body))
    cols = s.get("cols") or max(1, min(len(items), 3))
    return (sec_head(s.get("title"))
            + '<div class="metrics" style="grid-template-columns:repeat(%d,1fr)">%s</div>'
            % (cols, "".join(cells)))


def r_ladder(s):
    rows = []
    for it in s.get("items", []):
        out = ""
        if it.get("output"):
            out = ('<div class="out bd"><span class="em">%s</span>产出：%s</div>'
                   % (esc(it.get("output_emoji", "📦")), esc(it["output"])))
        desc = ('<div class="d">%s</div>' % inline(it["desc"])) if it.get("desc") else ""
        rows.append('<div class="lad"><div class="lad-tag bd">'
                    '<span class="lv">%s</span><span class="nm">%s</span></div>'
                    '<div class="lad-bd"><div class="t bd">%s</div>%s%s</div></div>'
                    % (esc(it.get("level", "")), esc(it.get("name", "")),
                       inline(it.get("title", "")), desc, out))
    return sec_head(s.get("title")) + '<div class="card pad">%s</div>' % "".join(rows)


def r_overview(s):
    rows = []
    for i, d in enumerate(s.get("days", []), 1):
        tag = ('<span class="ov-tag bd">%s</span>' % esc(d["tag"])) if d.get("tag") else ""
        desc = ('<div class="d">%s</div>' % inline(d["desc"])) if d.get("desc") else ""
        res = ""
        if d.get("result"):
            res = ('<div class="out bd"><span class="em">%s</span>成果：%s</div>'
                   % (esc(d.get("result_emoji", "🎯")), esc(d["result"])))
        rows.append('<div class="ov"><div class="ov-head">'
                    '<span class="ov-pill bd">%s</span>%s</div>'
                    '<div class="t bd">%s</div>%s%s</div>'
                    % (esc(d.get("label") or ("DAY %d" % i)), tag,
                       inline(d.get("title", "")), desc, res))
    return sec_head(s.get("title")) + '<div class="card pad">%s</div>' % "".join(rows)


def r_scenarios(s):
    cards = []
    for it in s.get("items", []):
        flow = it.get("flow") or []
        if isinstance(flow, str):
            flow = [flow]
        flow_html = '<span class="ar">→</span>'.join(esc(x) for x in flow)
        inv = ""
        if it.get("involves"):
            inv = '<div class="inv bd">涉及：%s</div>' % esc(it["involves"])
        em = ('<span class="em">%s</span>' % esc(it["emoji"])) if it.get("emoji") else ""
        cards.append('<div class="scn"><div class="t bd">%s<span>%s</span></div>'
                     '<div class="fl">%s</div>%s</div>'
                     % (em, esc(it.get("title", "")), flow_html, inv))
    return sec_head(s.get("title")) + "".join(cards)


def r_compare(s):
    head = ('<div class="cmp-row cmp-head"><div class="cmp-cell l bd">%s</div>'
            '<div class="cmp-cell r bd">%s</div></div>'
            % (esc(s.get("left_header", "传统做法")), esc(s.get("right_header", "本课程"))))
    rows = []
    for r in s.get("rows", []):
        rows.append('<div class="cmp-row"><div class="cmp-cell l">%s</div>'
                    '<div class="cmp-cell r bd">%s</div></div>'
                    % (esc(r.get("left", "")), esc(r.get("right", ""))))
    return sec_head(s.get("title")) + '<div class="cmp">%s%s</div>' % (head, "".join(rows))


def r_valuegrid(s):
    items = s.get("items", [])
    cells = []
    for it in items:
        lb = ('<div class="l bd">%s</div>' % esc(it["label"])) if it.get("label") else ""
        d = ('<div class="d">%s</div>' % inline(it["desc"])) if it.get("desc") else ""
        cells.append('<div class="vg-cell"><div class="m hv">%s</div>%s%s</div>'
                     % (esc(it.get("metric", "")), lb, d))
    cols = s.get("cols") or 2
    return (sec_head(s.get("title"))
            + '<div class="vg" style="grid-template-columns:repeat(%d,1fr)">%s</div>'
            % (cols, "".join(cells)))


def r_footer_cta(s):
    sub = ('<div class="s">%s</div>' % esc(s["sub"])) if s.get("sub") else ""
    chips = ""
    if s.get("tags"):
        chips = ('<div class="chips">%s</div>'
                 % "".join('<span class="chip bd">%s</span>' % esc(t) for t in s["tags"]))
    qr_html = ""
    qr = None
    if s.get("qr_image") and os.path.exists(s["qr_image"]):
        qr = img_data_uri(s["qr_image"])
    elif s.get("qr_url"):
        try:
            qr = make_qr_data_uri(s["qr_url"])
        except Exception as e:
            sys.stderr.write("QR 生成失败(%s)，跳过二维码\n" % e)
    if qr:
        cap = ('<div class="qrcap">%s</div>' % esc(s["qr_caption"])) if s.get("qr_caption") else ""
        qr_html = ('<div class="qrwrap"><img src="%s" width="248" height="248" alt=""></div>%s'
                   % (qr[0], cap))
    brand = ""
    if s.get("brand_logo", "logo_cn.png"):
        buri, bw0, bh0 = logo(s.get("brand_logo", "logo_cn.png"))
        bw = 250
        bh = int(round(bh0 * bw / bw0))
        brand = ('<div class="fbrand"><img src="%s" width="%d" height="%d" alt=""></div>'
                 % (buri, bw, bh))
    return ('<section class="fcta"><div class="h hv">%s</div>%s%s%s%s</section>'
            % (esc(s.get("headline", "")), sub, chips, qr_html, brand))


RENDERERS = {
    "intro": r_intro, "goals": r_goals, "schedule": r_schedule, "gains": r_gains,
    "audience": r_audience, "logistics": r_logistics, "quote": r_quote, "cta": r_cta,
    "metrics": r_metrics, "ladder": r_ladder, "overview": r_overview,
    "scenarios": r_scenarios, "compare": r_compare, "valuegrid": r_valuegrid,
    "footer_cta": r_footer_cta,
}


def build_html(data):
    parts = [r_hero(data.get("hero", {}), data.get("brand", {}))]
    for s in data.get("sections", []):
        t = s.get("type")
        if t not in RENDERERS:
            sys.stderr.write("未知模块类型: %s（已跳过）\n" % t)
            continue
        parts.append(RENDERERS[t](s))
    css = themed_css(CSS + CSS2, data.get("theme", "classic"))
    return """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>poster</title>
<style>%s</style></head>
<body><div class="page">%s</div>
<script>document.title='PH:'+document.documentElement.scrollHeight;</script>
</body></html>""" % (css, "\n".join(parts))


# ---------------------------------------------------------------- render

def run_chrome(chrome, args, timeout=90):
    cmd = [chrome, "--headless=new", "--disable-gpu", "--hide-scrollbars",
           "--no-sandbox", "--force-device-scale-factor=1"] + args
    try:
        return subprocess.run(cmd, capture_output=True, timeout=timeout).stdout
    except subprocess.TimeoutExpired as e:
        return e.stdout or b""


def measure_height(chrome, html_path):
    out = run_chrome(chrome, ["--virtual-time-budget=4000", "--dump-dom",
                              "file://" + html_path], timeout=90)
    m = re.search(rb"PH:(\d+)", out or b"")
    if m:
        return int(m.group(1))
    sys.stderr.write("高度探测失败，回退 20000px\n")
    return 20000


def screenshot(chrome, html_path, out_png, height):
    if os.path.exists(out_png):
        os.remove(out_png)
    args = ["--virtual-time-budget=6000",
            "--window-size=%d,%d" % (PAGE_W, height),
            "--screenshot=" + out_png, "file://" + html_path]
    proc = subprocess.Popen([chrome, "--headless=new", "--disable-gpu", "--hide-scrollbars",
                             "--no-sandbox", "--force-device-scale-factor=1"] + args,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # Chrome headless 有时不自退：轮询产物大小稳定两次即收工
    last, stable, waited = -1, 0, 0.0
    while waited < 120:
        time.sleep(0.6); waited += 0.6
        if proc.poll() is not None:
            break
        sz = os.path.getsize(out_png) if os.path.exists(out_png) else 0
        if sz > 0 and sz == last:
            stable += 1
            if stable >= 2:
                break
        else:
            stable = 0
        last = sz
    if proc.poll() is None:
        proc.kill()
    if not os.path.exists(out_png):
        raise SystemExit("截图失败：未生成 %s" % out_png)


def trim_bottom(png):
    """按洋红哨兵色裁掉页面之外的画布，得到精确内容高度。.page 自带下边距，无需额外留白。"""
    from PIL import Image
    im = Image.open(png).convert("RGB")
    w, h = im.size
    px = im.load()

    def is_sentinel(y):
        for x in range(0, w, 11):
            p = px[x, y]
            if not (p[0] > 200 and p[1] < 90 and p[2] > 200):
                return False
        return True

    last = h - 1
    y = h - 1
    while y >= 0:
        if not is_sentinel(y):
            last = y
            break
        y -= 1
    if last + 1 < h:
        im = im.crop((0, 0, w, last + 1))
        im.save(png)
    return im.size


def slice_png(png, out_dir, name, max_h=9000):
    """按近纯白/近纯背景行切片，避免切断文字。"""
    from PIL import Image
    im = Image.open(png).convert("RGB")
    w, h = im.size
    if h <= max_h:
        return [png]
    px = im.load()

    def bg_score(y):
        d = 0
        for x in range(0, w, 7):
            p = px[x, y]
            d += abs(p[0] - PAGE_BG[0]) + abs(p[1] - PAGE_BG[1]) + abs(p[2] - PAGE_BG[2])
        return d

    outs, top, idx = [], 0, 1
    while top < h:
        if h - top <= max_h:
            bot = h
        else:
            target = top + max_h
            best, best_s = target, None
            for y in range(target, max(target - 900, top + 400), -1):
                s = bg_score(y)
                if best_s is None or s < best_s:
                    best_s, best = s, y
                if s == 0:
                    break
            bot = best
        p = os.path.join(out_dir, "%s_%02d.png" % (name, idx))
        im.crop((0, top, w, bot)).save(p)
        outs.append(p)
        top, idx = bot, idx + 1
    return outs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("content", help="内容 JSON 路径")
    ap.add_argument("-o", "--out", required=True, help="输出目录")
    ap.add_argument("--name", default="course_poster", help="输出文件名（无扩展）")
    ap.add_argument("--keep-html", action="store_true", help="保留中间 HTML")
    ap.add_argument("--slice", action="store_true", help="额外输出切片图")
    ap.add_argument("--max-slice-h", type=int, default=9000)
    args = ap.parse_args()

    with open(args.content, encoding="utf-8") as f:
        data = json.load(f)

    # file:// URL 必须是绝对路径，否则 Chrome 渲染的是"文件未找到"错误页
    out_dir = os.path.abspath(args.out)
    os.makedirs(out_dir, exist_ok=True)
    html = build_html(data)
    html_path = os.path.join(out_dir, args.name + ".html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)

    chrome = find_chrome()
    h = measure_height(chrome, html_path)
    png = os.path.join(out_dir, args.name + ".png")
    screenshot(chrome, html_path, png, h + 160)
    w, hh = trim_bottom(png)
    print("海报: %s (%d×%d)" % (png, w, hh))
    if hh * w > 16_000_000:
        print("提示: %.1f Mpx 超过 iOS Safari 单图约 16.7Mpx 上限，建议加 --slice" % (hh * w / 1e6))
    if args.slice:
        for p in slice_png(png, out_dir, args.name, args.max_slice_h):
            print("切片: %s" % p)
    if not args.keep_html:
        os.remove(html_path)
    else:
        print("HTML: %s" % html_path)


if __name__ == "__main__":
    main()
